package com.mygdx.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;


import java.awt.Rectangle;
import java.util.LinkedList;
import java.util.ListIterator;

public class GamePlayScreen implements Screen {
    private Game game;
    Rectangle boundingBox; // this is some kind of hitbox
    Dot dot;
    private Texture mazeTexture;
    private SpriteBatch batch;
    private Texture dotTexture, coinTexture;
    private Coin coin1, coin2, coin3;
    private Animation<TextureRegion> coinAnimation;
    private LinkedList<Coin> coinLinkedList;
    private float dotX, dotY;
    private final float DOT_SIZE = 30.0f; // This should be the size of your dot
    private final float MOVE_AMOUNT = 2.0f;
    private boolean[][] collisionMap;
    private float UNIT_PER_PIXEL = 1.0f;

    private float START_X = 2 * 32; // Adjust to tile size and starting tile position
    private float START_Y = 2 * 32; // Adjust to tile size and starting tile position

    private final float COLLISION_BUFFER_RATIO = 0.1f;

    private Texture char2Texture; // Texture for the second player
    private Dot player2; // Second player character
    private float player2X, player2Y; // Position of the second player
    private final float PLAYER2_START_X = 10 * 32; // Starting X for player 2
    private final float PLAYER2_START_Y = 10 * 32; // Starting Y for player 2
    private boolean gamePaused = false;
    private Animation<TextureRegion> winAnimation;
    private float animationTime = 0;

    private float alpha = 0; // For fade effect
    private boolean isFadingOut = false;
    private BitmapFont font = new BitmapFont();
    private GlyphLayout layout = new GlyphLayout();



    public GamePlayScreen(Game game) {
        this.game = game;
        //coin animation
        batch = new SpriteBatch();
        coinTexture = new Texture("Coins.png");

        int frameWidth = coinTexture.getWidth() / 6;
        int frameHeight = coinTexture.getHeight();

        float frameDuration = 0.1f;
        TextureRegion[][] frames = TextureRegion.split(coinTexture, frameWidth, frameHeight);
        TextureRegion[] animationFrames = frames[0];
        coinAnimation = new Animation<>(frameDuration, animationFrames);


        //still very dirty assigning need to improve but it's working
        coin1 = new Coin(198, 304, 10, 10, frameDuration, null, animationFrames);
        coin2 = new Coin(97, 78, 10, 10, frameDuration, null, animationFrames);
        coin3 = new Coin(300, 128, 10, 10, frameDuration, null, animationFrames);

        coinLinkedList = new LinkedList<>();
        coinLinkedList.add(coin1);
        coinLinkedList.add(coin2);
        coinLinkedList.add(coin3);

        batch = new SpriteBatch();
    }

    @Override
    public void show() {
        mazeTexture = new Texture("gamemap.jpeg");
        dotTexture = new Texture("dot.png"); // Make sure you have a dot.png in your assets
        char2Texture = new Texture("char2.png"); // Load the second player's texture
        player2 = new Dot(PLAYER2_START_X, PLAYER2_START_Y + 6, 30f, 30f, char2Texture); // Initialize player 2
        batch = new SpriteBatch();

        // Set your desired margins on the sides
        // Set your desired margins on the sides and top/bottom if needed
        float sideMargin = 50f; // Margin for sides in pixels
        float topBottomMargin = 50f; // Margin for top and bottom in pixels

        float screenWidth = Gdx.graphics.getWidth();
        float screenHeight = Gdx.graphics.getHeight();

        // Calculate scale ratios for both width and height
        float scaleRatioWidth = (screenWidth - 2 * sideMargin) / mazeTexture.getWidth();
        float scaleRatioHeight = (screenHeight - 2 * topBottomMargin) / mazeTexture.getHeight();

        // Choose the smaller ratio to ensure the texture fits on the screen
        UNIT_PER_PIXEL = Math.min(scaleRatioWidth, scaleRatioHeight);

        // Calculate the new starting X and Y positions to center the maze texture
        START_X = (screenWidth - mazeTexture.getWidth() * UNIT_PER_PIXEL) / 2;
        START_Y = (screenHeight - mazeTexture.getHeight() * UNIT_PER_PIXEL) / 2;

        Array<TextureRegion> frames = new Array<>();
        int numberOfFrames = 5; // Adjust this based on the number of frames you have
        for (int i = 1; i <= numberOfFrames; i++) {
            String fileName = "frame" + i + ".png";
            frames.add(new TextureRegion(new Texture(Gdx.files.internal(fileName))));
        }
        winAnimation = new Animation<>(0.1f, frames, Animation.PlayMode.NORMAL);

        // Initialize the dot's starting position
        dotX = START_X; // Adjust this to be within the bounds of your maze
        dotY = START_Y; // Adjust this as well


        dot = new Dot(START_X, START_Y + 6, 30f, 30f, dotTexture);


        createCollisionMap();

    }



    private void createCollisionMap() {
        if (!mazeTexture.getTextureData().isPrepared()) {
            mazeTexture.getTextureData().prepare();
        }
        Pixmap pixmap = mazeTexture.getTextureData().consumePixmap();

        collisionMap = new boolean[pixmap.getWidth()][pixmap.getHeight()];
        // Iterate through all pixels in the pixmap
        for (int y = 0; y < pixmap.getHeight(); y++) {
            for (int x = 0; x < pixmap.getWidth(); x++) {
                // LibGDX pixmap coordinates start at the top left, so invert the y-axis
                int pixel = pixmap.getPixel(x, pixmap.getHeight() - 1 - y);
                // Check if the pixel is significantly green. This example uses a simple
                // threshold check. Adjust the threshold according to your specific color.
                collisionMap[x][y] = (pixel != 0xFFFFFFFF);
            }
        }

        // Debugging: Print the collision map
        for (int y = 0; y < pixmap.getHeight(); y++) {
            for (int x = 0; x < pixmap.getWidth(); x++) {
                System.out.print(collisionMap[x][y] ? "1" : "0");
            }
            System.out.println();
        }

        pixmap.dispose();
    }

    private void handleInput() {
        float potentialX = player2.boundingBox.x;
        float potentialY = player2.boundingBox.y;

        if (Gdx.input.isKeyPressed(Input.Keys.A)) {
            potentialX -= MOVE_AMOUNT;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.D)) {
            potentialX += MOVE_AMOUNT;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.W)) {
            potentialY += MOVE_AMOUNT;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.S)) {
            potentialY -= MOVE_AMOUNT;
        }

        if (!collidesWithWall(potentialX, potentialY)) {
            player2.boundingBox.x = potentialX;
            player2.boundingBox.y = potentialY;
        }
    }

    private boolean checkPlayerCollision() {
        // This is a simple AABB (Axis-Aligned Bounding Box) collision check
        return dot.boundingBox.overlaps(player2.boundingBox);
    }


    private void handleInput_1() {
        float potentialX = dot.boundingBox.x;
        float potentialY = dot.boundingBox.y;

        if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
            potentialX -= MOVE_AMOUNT;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
            potentialX += MOVE_AMOUNT;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.UP)) {
            potentialY += MOVE_AMOUNT;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
            potentialY -= MOVE_AMOUNT;
            System.out.println(collidesWithWall(potentialX, potentialY));
        }

        if (!collidesWithWall(potentialX, potentialY)) {
            dot.boundingBox.x = potentialX;
            dot.boundingBox.y = potentialY;
        }
    }

    private boolean collidesWithWall(float x, float y) {
        // Reduce the collision check to the center of the dot to avoid edge issues
        int centerX = (int) ((x + DOT_SIZE / 2) / UNIT_PER_PIXEL);
        int centerY = (int) ((y + DOT_SIZE / 2) / UNIT_PER_PIXEL);

        // Apply a small buffer around the dot's center for collision detection
        int bufferX = (int) (DOT_SIZE * COLLISION_BUFFER_RATIO / UNIT_PER_PIXEL);
        int bufferY = (int) (DOT_SIZE * COLLISION_BUFFER_RATIO / UNIT_PER_PIXEL);

        // Check the area around the dot's center for collisions, using the buffer
        for (int checkX = centerX - bufferX; checkX <= centerX + bufferX; checkX++) {
            for (int checkY = centerY - bufferY; checkY <= centerY + bufferY; checkY++) {
                // Check if this point is a wall
                if (isWall(checkX, checkY)) {
                    return true; // Collision found at this point
                }
            }
        }

        return false; // No collision found around the dot's center
    }

    private boolean isWall(int x, int y) {
        // Check if the coordinates are out of bounds
        if (x < 0 || x >= collisionMap.length || y < 0 || y >= collisionMap[0].length) {
            return true; // Treat out-of-bounds as a wall
        }
        return collisionMap[x][y];
    }

    public void coinCollision(float delta) {
        ListIterator<Coin> iterator = coinLinkedList.listIterator();

        while (iterator.hasNext()) {
            Coin coin = iterator.next();

            if (dot.intersects(coin.boundingBox)) {
                //dot1.coinCounter++
                iterator.remove();
            }
        }
    }


    @Override
    public void render(float delta) {
        // Update the fade-out effect
        if (isFadingOut) {
            alpha -= delta;
            if (alpha <= 0) {
                resetGame();
            }
        }

        // Clear the screen
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        // Handle input and update game logic
        if (!gamePaused) {
            handleInput();
            handleInput_1();
            updateCoins(delta);
        }

        // Start drawing
        batch.begin();

        // Draw the game world
        drawGameplay(batch);

        // Draw the fading effect and win animation if the game is paused
        if (gamePaused) {
            drawFadingEffect(batch);
            drawWinAnimation(delta);
        }

        // End drawing
        batch.end();

        // Check for player collision and handle game over
        if (checkPlayerCollision() && !gamePaused) {
            gameOver();
        }
    }


    private void updateCoins(float delta) {
        ListIterator<Coin> iterator = coinLinkedList.listIterator();
        while (iterator.hasNext()) {
            Coin coin = iterator.next();
            coin.update(delta); // Advance the animation frame for each coin

            if (dot.intersects(coin.boundingBox)) {
                iterator.remove(); // Remove the coin if there's a collision with the player
            }
        }
    }

    private void drawGameplay(SpriteBatch batch) {
        // Draw the maze background
        float screenWidth = Gdx.graphics.getWidth();
        float screenHeight = Gdx.graphics.getHeight();
        float mazeWidth = mazeTexture.getWidth();
        float mazeHeight = mazeTexture.getHeight();
        float startX = (screenWidth - mazeWidth * UNIT_PER_PIXEL) / 2;
        float startY = (screenHeight - mazeHeight * UNIT_PER_PIXEL) / 2;
        batch.draw(mazeTexture, START_X, START_Y, mazeTexture.getWidth() * UNIT_PER_PIXEL, mazeTexture.getHeight() * UNIT_PER_PIXEL);
        // Draw coins
        for (Coin coin : coinLinkedList) {
            coin.render(batch, startX, startY);
        }

        // Draw the player character dots
        dot.draw(batch, startX, startY); // Assuming your Dot's draw method takes into account the offset
        player2.draw(batch, startX, startY); // Same as above for the second dot

        // If there's any other gameplay elements to draw, include them here
    }


    private void drawWinAnimation(float delta) {
        // Play the win animation at the center of the screen
        animationTime += delta;
        TextureRegion currentFrame = winAnimation.getKeyFrame(animationTime, false);
        if (winAnimation.isAnimationFinished(animationTime)) {
            isFadingOut = true; // Once the animation finishes, trigger fade out
        } else {
            // Draw the win banner animation
            float bannerX = (Gdx.graphics.getWidth() - currentFrame.getRegionWidth()) / 2f;
            float bannerY = (Gdx.graphics.getHeight() - currentFrame.getRegionHeight()) / 2f;
            batch.draw(currentFrame, bannerX, bannerY);
        }
    }

    private void drawFadingEffect(SpriteBatch batch) {
        // Set the batch to use the alpha value
        batch.setColor(1, 1, 1, alpha);
        // Draw a full-screen rectangle with the faded alpha
        // ... (Here, you may need to draw a fullscreen transparent texture or use ShapeRenderer)
        batch.setColor(1, 1, 1, 1); // Reset the batch color
    }

    private void resetGame() {
        dot.setPosition(START_X, START_Y);
        player2.setPosition(PLAYER2_START_X, PLAYER2_START_Y);
        gamePaused = false;
        isFadingOut = false;
        alpha = 1;
    }

    private void gameOver() {
        gamePaused = true;
        alpha = 1; // Start fade effect
        isFadingOut = false; // Reset for fade out
        animationTime = 0; // Reset animation time for win banner animation
        Gdx.app.log("GameOver", "Player 2 wins!");
    }


    @Override
    public void resize(int width, int height) {
        // Handle screen resizing
    }

    @Override
    public void pause() {
        // Handle game pausing
    }

    @Override
    public void resume() {
        // Handle game resuming
    }

    @Override
    public void hide() {
        for (TextureRegion frame : winAnimation.getKeyFrames()) {
            frame.getTexture().dispose();
        }
    }


    @Override
    public void dispose() {
        // Dispose of the batch and textures
        batch.dispose();
        char2Texture.dispose();
        mazeTexture.dispose();
        dotTexture.dispose();
        // Dispose of textures from the winAnimation
        for (TextureRegion region : winAnimation.getKeyFrames()) {
            region.getTexture().dispose();
        }
    }
}