package com.mygdx.game;

import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;


// can make an extension of dot 1 and dot2
public class Dot {
    Texture dotTexture;
    Rectangle boundingBox;
    public Dot(float xPosition, float yPosition, float width, float height, Texture dotTexture) {
        this.dotTexture = dotTexture;
        this.boundingBox = new Rectangle(xPosition, yPosition, width, height);
    }

    //hitbox of the dot or the character, this is also applicable if hitting the other dot or character
    public boolean intersects(Rectangle otherRectangle){
        return boundingBox.overlaps(otherRectangle);
    }

    public void draw(SpriteBatch batch, float offsetX, float offsetY) {
        // Draw the dot using its texture, position, and the offset
        batch.draw(dotTexture, boundingBox.x + offsetX, boundingBox.y + offsetY, boundingBox.width, boundingBox.height);
    }

    public void translate(float xChange, float yChange){
        boundingBox.x += xChange;
        boundingBox.y += yChange;
    }

    // Method to set the position of the dot
    public void setPosition(float x, float y) {
        boundingBox.x = x;
        boundingBox.y = y;
    }


}
